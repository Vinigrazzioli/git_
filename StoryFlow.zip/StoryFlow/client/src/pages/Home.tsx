import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSwipeable } from 'react-swipeable';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import MomentDetail from '@/components/MomentDetail';

const moments = [
  {
    id: 'pre-chatgpt',
    year: '2022',
    title: 'Era da Busca Tradicional',
    description: 'Um mundo onde as pessoas ainda dependiam do Google para encontrar informações.',
    color: 'from-zinc-900 to-zinc-800'
  },
  {
    id: 'chatgpt-emergence',
    year: '2022',
    title: 'ChatGPT Emerge',
    description: 'Uma revolução na forma como interagimos com a tecnologia.',
    color: 'from-emerald-900 to-emerald-800'
  },
  {
    id: 'ai-evolution',
    year: '2023',
    title: 'Evolução da IA',
    description: 'As capacidades multimodais expandem os horizontes.',
    color: 'from-blue-900 to-blue-800'
  },
  {
    id: 'agents-rise',
    year: '2024',
    title: 'Surgimento dos Agentes',
    description: 'IA evolui de conversas para ações autônomas.',
    color: 'from-purple-900 to-purple-800'
  },
  {
    id: 'sicredi-future',
    year: 'HOJE',
    title: 'O Futuro do Sicredi',
    description: 'Liderando a transformação com agentes inteligentes.',
    color: 'from-primary to-primary/80'
  }
];

export default function Home() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [detailOpen, setDetailOpen] = useState(false);

  const handlers = useSwipeable({
    onSwipedLeft: () => goToNext(),
    onSwipedRight: () => goToPrevious(),
    enabled: !detailOpen,
  });

  const goToNext = () => {
    if (currentIndex < moments.length - 1) {
      setCurrentIndex(prev => prev + 1);
    }
  };

  const goToPrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  return (
    <div className="h-screen w-screen overflow-hidden relative" {...handlers}>
      <AnimatePresence mode="wait">
        <motion.div
          key={`main-${currentIndex}`}
          initial={false}
          animate={{
            height: detailOpen ? '20vh' : '100vh',
          }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className={`w-full bg-gradient-to-br ${moments[currentIndex].color} flex items-center justify-center relative`}
        >
          <div className="absolute top-8 left-8">
            <motion.span 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl font-bold text-white/80"
            >
              {moments[currentIndex].year}
            </motion.span>
          </div>

          <div className="max-w-2xl text-center px-4">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ 
                opacity: 1, 
                y: 0,
                fontSize: detailOpen ? '2rem' : '4rem'
              }}
              transition={{ delay: 0.2 }}
              className="font-bold text-white mb-6"
            >
              {moments[currentIndex].title}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ 
                opacity: detailOpen ? 0 : 1,
                y: detailOpen ? -20 : 0
              }}
              transition={{ delay: 0.4 }}
              className="text-xl md:text-2xl text-white/80 mb-8"
            >
              {moments[currentIndex].description}
            </motion.p>

            <motion.button
              initial={{ opacity: 0, y: 20 }}
              animate={{ 
                opacity: detailOpen ? 0 : 1,
                y: detailOpen ? -20 : 0
              }}
              transition={{ delay: 0.6 }}
              onClick={() => setDetailOpen(true)}
              className="bg-white/20 hover:bg-white/30 text-white px-6 py-3 rounded-lg transition-colors"
            >
              Saiba Mais
            </motion.button>
          </div>

          {!detailOpen && (
            <>
              <div className="absolute bottom-8 left-0 right-0 flex justify-center gap-2">
                {moments.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentIndex(idx)}
                    className={`w-3 h-3 rounded-full transition-all ${
                      idx === currentIndex ? 'bg-white scale-125' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>

              {currentIndex > 0 && (
                <button
                  onClick={goToPrevious}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white transition-colors"
                >
                  <ChevronLeft size={48} />
                </button>
              )}

              {currentIndex < moments.length - 1 && (
                <button
                  onClick={goToNext}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white transition-colors"
                >
                  <ChevronRight size={48} />
                </button>
              )}
            </>
          )}

          {detailOpen && (
            <button
              onClick={() => setDetailOpen(false)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-white/80 hover:text-white transition-colors"
            >
              <X size={24} />
            </button>
          )}
        </motion.div>

        {detailOpen && (
          <motion.div
            key="detail"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="absolute inset-x-0 top-[20vh] bottom-0 bg-black"
          >
            <MomentDetail momentId={moments[currentIndex].id} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}