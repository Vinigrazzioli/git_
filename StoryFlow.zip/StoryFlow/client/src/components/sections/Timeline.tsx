import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';

const timelineItems = [
  { year: '2022', text: 'ChatGPT surpreende o mundo' },
  { year: '2023', text: 'Avanço das capacidades multimodais' },
  { year: '2024', text: 'Surgimento de agentes autônomos' },
  { year: 'HOJE', text: 'Oportunidade para o Sicredi liderar' }
];

export default function Timeline() {
  return (
    <section className="py-20">
      <motion.h2
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="text-4xl font-bold text-center mb-12"
      >
        Do ChatGPT aos Agentes Autônomos
      </motion.h2>

      <div className="max-w-4xl mx-auto">
        {timelineItems.map((item, index) => (
          <motion.div
            key={item.year}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.2 }}
            viewport={{ once: true }}
            className="flex items-center gap-8 mb-8"
          >
            <Card className="w-24 shrink-0">
              <CardContent className="p-4 text-center font-bold">
                {item.year}
              </CardContent>
            </Card>
            
            <div className="flex-1">
              <Card>
                <CardContent className="p-4">
                  {item.text}
                </CardContent>
              </Card>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
