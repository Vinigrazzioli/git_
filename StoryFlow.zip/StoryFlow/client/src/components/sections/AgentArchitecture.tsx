import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';

const components = [
  { title: 'LLMs', desc: 'O cérebro do agente (similar ao ChatGPT)' },
  { title: 'Memória', desc: 'Contexto e aprendizado' },
  { title: 'Ferramentas', desc: 'Interfaces com sistemas' },
  { title: 'Orquestração', desc: 'Coordenação de ações (LangGraph)' }
];

export default function AgentArchitecture() {
  return (
    <section className="py-20">
      <motion.h2
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="text-4xl font-bold text-center mb-12"
      >
        Anatomia do Futuro
      </motion.h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {components.map((component, index) => (
          <motion.div
            key={component.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.2 }}
            viewport={{ once: true }}
          >
            <Card className="h-full">
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold mb-4 text-primary">
                  {component.title}
                </h3>
                <p className="text-muted-foreground">
                  {component.desc}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="text-center mt-12 text-lg max-w-2xl mx-auto"
      >
        "Pense no ChatGPT como um funcionário inteligente, mas que só pode conversar. 
        Um agente é como um funcionário que conversa E executa tarefas completas."
      </motion.p>
    </section>
  );
}
