import { motion } from 'framer-motion';
import CodeBlock from '../CodeBlock';

const sampleCode = `from langgraph.graph import Graph

# Nós do grafo
def analisar_solicitacao(state):
    # Analisa a solicitação do cooperado
    return state

def consultar_sistemas(state):
    # Consulta APIs do Sicredi
    return state

def decidir_proximos_passos(state):
    # Determina o que fazer em seguida
    return state

# Construindo o grafo
builder = Graph()
builder.add_node("analisar", analisar_solicitacao)
builder.add_node("consultar", consultar_sistemas)
builder.add_node("decidir", decidir_proximos_passos)

# Definindo as conexões
builder.add_edge("analisar", "consultar")
builder.add_edge("consultar", "decidir")
builder.add_edge("decidir", "analisar")  # Loop quando necessário

agente = builder.compile()`;

export default function Implementation() {
  return (
    <section className="py-20">
      <motion.h2
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="text-4xl font-bold text-center mb-12"
      >
        Como Construímos Isso?
      </motion.h2>

      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold mb-6">LangGraph em Ação</h3>
          <CodeBlock code={sampleCode} />
        </motion.div>
      </div>
    </section>
  );
}
