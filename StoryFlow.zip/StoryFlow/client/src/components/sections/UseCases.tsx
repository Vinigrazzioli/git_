import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Atual', value: 100 },
  { name: 'Com Agentes', value: 160 }
];

export default function UseCases() {
  return (
    <section className="py-20">
      <motion.h2
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="text-4xl font-bold text-center mb-12"
      >
        Impacto Sistêmico
      </motion.h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <Card className="h-full">
            <CardContent className="p-6">
              <h3 className="text-2xl font-bold mb-6">Eficiência Operacional</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#009A44" 
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <p className="mt-4 text-muted-foreground">
                Redução de 30-40% em tarefas repetitivas
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <Card className="h-full">
            <CardContent className="p-6">
              <h3 className="text-2xl font-bold mb-6">Experiência do Cooperado</h3>
              <ul className="space-y-4">
                <li>✓ Atendimento personalizado 24/7</li>
                <li>✓ Análise de crédito mais ágil e precisa</li>
                <li>✓ Gestão de riscos proativa</li>
                <li>✓ Recomendações personalizadas</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
