import { motion } from 'framer-motion';
import Particles from '../Particles';

export default function HeroSection() {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center text-center py-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <Particles 
          text="AGENTES DE IA" 
          className="text-6xl md:text-8xl text-primary mb-6"
        />
        
        <motion.h2
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-2xl md:text-3xl text-muted-foreground mb-8"
        >
          Transformando o Futuro do Sicredi
        </motion.h2>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-xl md:text-2xl font-light max-w-2xl mx-auto"
        >
          "O futuro não é algo que acontece conosco.
          É algo que nós criamos."
        </motion.p>
      </motion.div>
    </section>
  );
}
