import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';

const phases = [
  { title: 'Fase 1', desc: 'Prova de conceito em áreas específicas' },
  { title: 'Fase 2', desc: 'Integração com sistemas legados' },
  { title: 'Fase 3', desc: 'Implementação supervisionada' },
  { title: 'Fase 4', desc: 'Expansão para todo o sistema' }
];

export default function Roadmap() {
  return (
    <section className="py-20">
      <motion.h2
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="text-4xl font-bold text-center mb-12"
      >
        Jornada de Transformação
      </motion.h2>

      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {phases.map((phase, index) => (
            <motion.div
              key={phase.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="h-full">
                <CardContent className="p-6">
                  <h3 className="text-2xl font-bold mb-4 text-primary">
                    {phase.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {phase.desc}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-12 text-lg font-light"
        >
          "Começamos pequeno, aprendemos rápido, expandimos com confiança"
        </motion.p>
      </div>
    </section>
  );
}
