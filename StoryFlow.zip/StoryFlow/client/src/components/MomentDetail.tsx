import { motion } from 'framer-motion';
import { MessageSquare, Copy, Bot, Zap, Brain, FileText, Users, Briefcase, Camera, Music, Layout } from 'lucide-react';

interface MomentDetailProps {
  momentId: string;
}

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: 20 }
};

export default function MomentDetail({ momentId }: MomentDetailProps) {
  if (momentId === 'chatgpt-emergence') {
    return (
      <div className="p-8 text-white overflow-y-auto h-full bg-gradient-to-b from-emerald-900/50 to-black">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold mb-12 text-center"
        >
          ChatGPT e o Poder dos LLMs
        </motion.h2>

        <div className="grid gap-12 max-w-4xl mx-auto">
          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.2 }}
            className="flex items-start gap-6 bg-white/5 p-8 rounded-xl backdrop-blur-sm"
          >
            <Brain size={48} className="text-primary shrink-0 mt-2" />
            <div>
              <h3 className="text-2xl font-bold mb-4">LLMs: Um Cérebro Digital</h3>
              <p className="text-white/80 mb-6 text-lg leading-relaxed">
                Imagine uma biblioteca gigante onde todos os livros foram lidos por um 
                super-estudante. Esse é o LLM (Large Language Model)! Como uma pessoa 
                que leu muito, ele consegue:
              </p>
              <motion.ul className="space-y-4 text-white/70">
                <motion.li 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="flex items-center gap-4 bg-white/5 p-4 rounded-lg"
                >
                  <span className="text-primary text-2xl">📚</span>
                  <span>Entender perguntas como um bibliotecário experiente</span>
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="flex items-center gap-4 bg-white/5 p-4 rounded-lg"
                >
                  <span className="text-primary text-2xl">💭</span>
                  <span>Explicar conceitos complexos de forma simples</span>
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8 }}
                  className="flex items-center gap-4 bg-white/5 p-4 rounded-lg"
                >
                  <span className="text-primary text-2xl">🗣️</span>
                  <span>Conversar naturalmente em vários idiomas</span>
                </motion.li>
              </motion.ul>
            </div>
          </motion.div>

          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 1.0 }}
            className="grid md:grid-cols-2 gap-6"
          >
            <div className="bg-white/5 p-8 rounded-xl backdrop-blur-sm">
              <MessageSquare size={32} className="text-primary mb-4" />
              <h3 className="text-xl font-bold mb-4">O Que Ele Faz Bem</h3>
              <ul className="space-y-3 text-white/70">
                <li className="flex items-center gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Responde perguntas com contexto</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Auxilia em análises complexas</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Sugere soluções criativas</span>
                </li>
              </ul>
            </div>

            <div className="bg-white/5 p-8 rounded-xl backdrop-blur-sm">
              <FileText size={32} className="text-primary mb-4" />
              <h3 className="text-xl font-bold mb-4">Suas Limitações</h3>
              <ul className="space-y-3 text-white/70">
                <li className="flex items-center gap-2">
                  <span className="text-red-400">×</span>
                  <span>Não acessa sistemas diretamente</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-red-400">×</span>
                  <span>Precisa de humanos para agir</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-red-400">×</span>
                  <span>Conhecimento limitado ao treino</span>
                </li>
              </ul>
            </div>
          </motion.div>

          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 1.4 }}
            className="bg-gradient-to-r from-emerald-900/30 to-black/30 p-8 rounded-xl backdrop-blur-sm"
          >
            <h3 className="text-2xl font-bold mb-6 text-center">Como Funciona na Prática</h3>
            <div className="flex flex-col md:flex-row gap-8 items-center justify-center">
              <div className="text-center">
                <span className="text-6xl mb-4 block">🤔</span>
                <p className="text-white/70">Usuário pergunta</p>
              </div>
              <div className="text-4xl text-primary">→</div>
              <div className="text-center">
                <span className="text-6xl mb-4 block">🧠</span>
                <p className="text-white/70">IA processa</p>
              </div>
              <div className="text-4xl text-primary">→</div>
              <div className="text-center">
                <span className="text-6xl mb-4 block">💬</span>
                <p className="text-white/70">Resposta natural</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  if (momentId === 'ai-evolution') {
    return (
      <div className="p-8 text-white overflow-y-auto h-full bg-gradient-to-b from-blue-900/50 to-black">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold mb-12 text-center"
        >
          A Era Multimodal: IA Além do Texto
        </motion.h2>

        <div className="grid gap-12 max-w-4xl mx-auto">
          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.2 }}
            className="bg-white/5 p-8 rounded-xl backdrop-blur-sm"
          >
            <Layout size={48} className="text-primary mb-6" />
            <h3 className="text-2xl font-bold mb-6">O Que é Multimodal?</h3>
            <p className="text-white/80 mb-8 text-lg leading-relaxed">
              Se antes a IA só entendia texto, agora ela é como uma pessoa que pode:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="bg-white/10 p-6 rounded-lg text-center transform hover:scale-105 transition-transform"
              >
                <Camera size={48} className="text-primary mx-auto mb-4" />
                <h4 className="font-bold mb-2">Ver Imagens</h4>
                <p className="text-sm text-white/70">
                  Analisa fotos e documentos como um especialista
                </p>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="bg-white/10 p-6 rounded-lg text-center transform hover:scale-105 transition-transform"
              >
                <Music size={48} className="text-primary mx-auto mb-4" />
                <h4 className="font-bold mb-2">Ouvir Áudio</h4>
                <p className="text-sm text-white/70">
                  Entende e transcreve conversas naturalmente
                </p>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="bg-white/10 p-6 rounded-lg text-center transform hover:scale-105 transition-transform"
              >
                <MessageSquare size={48} className="text-primary mx-auto mb-4" />
                <h4 className="font-bold mb-2">Responder</h4>
                <p className="text-sm text-white/70">
                  Combina todas as informações em respostas completas
                </p>
              </motion.div>
            </div>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
              variants={fadeInUp}
              initial="initial"
              animate="animate"
              transition={{ delay: 1.0 }}
              className="bg-white/5 p-8 rounded-xl backdrop-blur-sm"
            >
              <h3 className="text-2xl font-bold mb-6">Antes da Era Multimodal</h3>
              <ul className="space-y-4 text-white/70">
                <li className="flex items-center gap-3">
                  <span className="text-red-400">×</span>
                  <span>Digitalização manual e demorada</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="text-red-400">×</span>
                  <span>Análise individual de cada formato</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="text-red-400">×</span>
                  <span>Processos fragmentados</span>
                </li>
              </ul>
            </motion.div>

            <motion.div
              variants={fadeInUp}
              initial="initial"
              animate="animate"
              transition={{ delay: 1.2 }}
              className="bg-white/5 p-8 rounded-xl backdrop-blur-sm"
            >
              <h3 className="text-2xl font-bold mb-6">Com IA Multimodal</h3>
              <ul className="space-y-4 text-white/70">
                <li className="flex items-center gap-3">
                  <span className="text-green-400">✓</span>
                  <span>Extração automática de dados</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="text-green-400">✓</span>
                  <span>Análise unificada e inteligente</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="text-green-400">✓</span>
                  <span>Experiência integrada e natural</span>
                </li>
              </ul>
            </motion.div>
          </div>

          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 1.4 }}
            className="bg-gradient-to-r from-blue-900/30 to-black/30 p-8 rounded-xl backdrop-blur-sm text-center"
          >
            <h3 className="text-2xl font-bold mb-6">O Futuro é Multimodal</h3>
            <p className="text-white/80 text-lg leading-relaxed mb-8">
              "Imagine um assistente que não apenas lê e escreve, mas vê, ouve e 
              entende o mundo como nós. Esse é o poder da IA multimodal."
            </p>
            <div className="flex justify-center gap-6 text-4xl">
              👁️ 👂 💭 🗣️
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  if (momentId === 'agents-rise') {
    return (
      <div className="p-8 text-white overflow-y-auto h-full bg-gradient-to-b from-purple-900/50 to-black">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold mb-12 text-center"
        >
          Agentes de IA: A Nova Fronteira
        </motion.h2>

        <div className="grid gap-12 max-w-4xl mx-auto">
          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.2 }}
            className="bg-white/5 p-8 rounded-xl backdrop-blur-sm"
          >
            <h3 className="text-2xl font-bold mb-6 text-center">
              Do Conversar ao Fazer
            </h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="p-6 bg-white/10 rounded-lg">
                <h4 className="font-bold text-xl mb-4 text-yellow-400">Chatbots</h4>
                <ul className="space-y-3 text-white/70">
                  <li>• Apenas conversam</li>
                  <li>• Dependem de humanos</li>
                  <li>• Conhecimento limitado</li>
                </ul>
              </div>
              <div className="p-6 bg-white/10 rounded-lg">
                <h4 className="font-bold text-xl mb-4 text-green-400">Agentes</h4>
                <ul className="space-y-3 text-white/70">
                  <li>• Executam tarefas</li>
                  <li>• Acessam sistemas</li>
                  <li>• Aprendem continuamente</li>
                </ul>
              </div>
            </div>
          </motion.div>

          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.6 }}
            className="bg-white/5 p-8 rounded-xl backdrop-blur-sm"
          >
            <h3 className="text-2xl font-bold mb-6">Impacto no Mercado Global</h3>
            <div className="space-y-6">
              <div className="p-4 bg-white/10 rounded-lg">
                <h4 className="font-bold mb-2">🏦 Setor Financeiro</h4>
                <p className="text-white/70">
                  Análise de crédito automatizada, detecção de fraudes em tempo real
                </p>
              </div>
              <div className="p-4 bg-white/10 rounded-lg">
                <h4 className="font-bold mb-2">🏥 Saúde</h4>
                <p className="text-white/70">
                  Triagem de pacientes, análise de exames, agendamento inteligente
                </p>
              </div>
              <div className="p-4 bg-white/10 rounded-lg">
                <h4 className="font-bold mb-2">🏢 Empresas</h4>
                <p className="text-white/70">
                  Automação de processos, atendimento 24/7, gestão de documentos
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 1.0 }}
            className="bg-gradient-to-r from-purple-900/30 to-black/30 p-8 rounded-xl backdrop-blur-sm"
          >
            <h3 className="text-2xl font-bold mb-6 text-center">Como Funciona?</h3>
            <div className="flex flex-col md:flex-row gap-8 justify-center items-center">
              <div className="text-center">
                <span className="text-5xl mb-4 block">📝</span>
                <h4 className="font-bold mb-2">Regras Claras</h4>
                <p className="text-sm text-white/70">Critérios definidos</p>
              </div>
              <div className="text-4xl text-primary">+</div>
              <div className="text-center">
                <span className="text-5xl mb-4 block">🤖</span>
                <h4 className="font-bold mb-2">Execução</h4>
                <p className="text-sm text-white/70">Ação automatizada</p>
              </div>
              <div className="text-4xl text-primary">+</div>
              <div className="text-center">
                <span className="text-5xl mb-4 block">👥</span>
                <h4 className="font-bold mb-2">Supervisão</h4>
                <p className="text-sm text-white/70">Controle humano</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  if (momentId === 'sicredi-future') {
    return (
      <div className="p-8 text-white overflow-y-auto h-full bg-gradient-to-b from-primary/50 to-black">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold mb-12 text-center"
        >
          O Futuro é Cooperativo
        </motion.h2>

        <div className="grid gap-12 max-w-4xl mx-auto">
          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.2 }}
            className="bg-white/5 p-8 rounded-xl backdrop-blur-sm"
          >
            <h3 className="text-2xl font-bold mb-6">Tecnologia com Propósito</h3>
            <p className="text-white/80 mb-8 text-lg leading-relaxed">
              Nossa missão é utilizar a IA para fortalecer ainda mais os princípios cooperativistas:
            </p>
            <div className="grid grid-cols-2 gap-6">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="bg-white/10 p-6 rounded-lg transform hover:scale-105 transition-transform"
              >
                <h4 className="font-bold mb-2">🤝 Cooperação</h4>
                <p className="text-white/70">
                  Agentes de IA trabalham em conjunto com nossos colaboradores
                </p>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="bg-white/10 p-6 rounded-lg transform hover:scale-105 transition-transform"
              >
                <h4 className="font-bold mb-2">💚 Humanização</h4>
                <p className="text-white/70">
                  Mais tempo para relacionamentos significativos
                </p>
              </motion.div>
            </div>
          </motion.div>

          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.8 }}
            className="bg-white/5 p-8 rounded-xl backdrop-blur-sm"
          >
            <h3 className="text-2xl font-bold mb-6">Exemplo Prático: Crédito Consignado</h3>
            <div className="space-y-8">
              <div className="p-6 bg-white/10 rounded-lg">
                <h4 className="font-bold text-xl mb-4">Cenário Atual</h4>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-center gap-2">
                    <span className="text-red-400">•</span>
                    <span>3 horas por análise manual</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-red-400">•</span>
                    <span>Consulta em 5 sistemas diferentes</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-red-400">•</span>
                    <span>Alto risco de erro humano</span>
                  </li>
                </ul>
              </div>

              <div className="p-6 bg-white/10 rounded-lg">
                <h4 className="font-bold text-xl mb-4">Com Agentes de IA</h4>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-center gap-2">
                    <span className="text-green-400">•</span>
                    <span>Análise completa em minutos</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-400">•</span>
                    <span>Integração automática de dados</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-400">•</span>
                    <span>Aprovação de 80% dos casos</span>
                  </li>
                </ul>
              </div>
            </div>
          </motion.div>

          <motion.div
            variants={fadeInUp}
            initial="initial"
            animate="animate"
            transition={{ delay: 1.0 }}
            className="bg-gradient-to-r from-primary/30 to-black/30 p-8 rounded-xl backdrop-blur-sm text-center"
          >
            <h3 className="text-2xl font-bold mb-6">Nossa Visão</h3>
            <p className="text-white/80 text-xl mb-8">
              "No Sicredi, não estamos apenas adotando tecnologia,
              estamos reinventando o cooperativismo para a era digital."
            </p>
            <div className="flex justify-center items-center gap-8">
              <div className="text-center">
                <span className="text-6xl block mb-2">💚</span>
                <p className="text-sm text-white/70">Cooperativismo</p>
              </div>
              <div className="text-4xl text-primary">+</div>
              <div className="text-center">
                <span className="text-6xl block mb-2">🤖</span>
                <p className="text-sm text-white/70">Tecnologia</p>
              </div>
              <div className="text-4xl text-primary">=</div>
              <div className="text-center">
                <span className="text-6xl block mb-2">🚀</span>
                <p className="text-sm text-white/70">Futuro</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return null;
}