import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

interface ParticlesProps {
  text: string;
  className?: string;
}

export default function Particles({ text, className = "" }: ParticlesProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const chars = text.split('');
    const container = containerRef.current;
    
    if (!container) return;
    
    container.innerHTML = '';
    
    chars.forEach((char, i) => {
      const span = document.createElement('span');
      span.textContent = char;
      span.style.opacity = '0';
      span.style.transform = 'translateY(20px)';
      span.style.display = 'inline-block';
      container.appendChild(span);
      
      setTimeout(() => {
        span.style.transition = 'all 0.5s ease';
        span.style.opacity = '1';
        span.style.transform = 'translateY(0)';
      }, i * 100);
    });
  }, [text]);

  return (
    <motion.div 
      ref={containerRef}
      className={`font-bold ${className}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    />
  );
}
