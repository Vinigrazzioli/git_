import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';

interface CodeBlockProps {
  code: string;
  language?: string;
}

export default function CodeBlock({ code, language = 'python' }: CodeBlockProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="bg-zinc-950 p-4 overflow-x-auto">
        <pre className={`language-${language}`}>
          <code className="text-sm text-gray-200">{code}</code>
        </pre>
      </Card>
    </motion.div>
  );
}
