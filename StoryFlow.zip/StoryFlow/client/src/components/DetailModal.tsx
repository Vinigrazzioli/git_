import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface DetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
}

export default function DetailModal({ isOpen, onClose, children }: DetailModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className="fixed inset-x-4 top-[10%] bottom-[10%] z-50 overflow-y-auto md:inset-x-auto md:left-1/2 md:right-auto md:w-[90vw] md:max-w-3xl md:-translate-x-1/2"
          >
            <Card className="h-full overflow-hidden bg-black">
              <div className="relative h-full flex flex-col">
                <button
                  onClick={onClose}
                  className="absolute right-4 top-4 text-white/80 hover:text-white transition-colors z-10"
                >
                  <X size={24} />
                </button>
                <div className="flex-1 overflow-y-auto">
                  {children}
                </div>
              </div>
            </Card>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
